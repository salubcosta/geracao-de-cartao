<div class="painel text-center">
	<h3 class="text-success">Cartão-Verso disponível para baixar <span class="glyphicon glyphicon-picture"></span></h3>
	<hr />
	<h4 class="text-info">Abrir Cartão-verso na mesma ABA</h4>
	<a href="<?php echo URL;?>/assets/imagens/cartaogerado.PNG" type="submit" class="btn btn-primary" target="_self">
		<span class="glyphicon glyphicon-floppy-save"></span> Abrir Cartão - Verso
	</a>
<hr />
	<h4 class="text-danger">Abrir Cartão-verso em Nova ABA</h4>
	<a href="<?php echo URL;?>/assets/imagens/cartaogerado.PNG" type="submit" class="btn btn-primary" target="_blank">
		<span class="glyphicon glyphicon-floppy-save"></span> Abrir Cartão - Verso
	</a>
</div>