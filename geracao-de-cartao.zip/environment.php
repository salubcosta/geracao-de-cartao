<?php

//url - constante que dará o caminho principal do sistema
define('URL', 'http://localhost:8080/projetos_github/geracao-de-cartao');

//diretorio - constante que da o caminho
define('DIRETORIO',dirname(__FILE__));