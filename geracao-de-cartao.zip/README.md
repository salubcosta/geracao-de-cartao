# geracao-de-cartao

Este projeto trata-se da gera��o de cart�o de visita de clientes de forma

## Orienta��o:

1. Configurar o arquivo .htaccess para acessar o diret�rio de instala�a� correto.

2. Configurar o arquivo environment.php para definir a constante URL.

## Informa��es:

1. Projeto criado no Padr�o MV

2. Utilizado framework do twitter, vulgo - bootstrap.

=================

A ideia b�sica � que as pessoas interessadas em representar determinada empresa, acesse o sistema, preencha os dados
e imprima a frente e verso do cart�o. Tanto a empresa quanto quanto os representantes ganham com este projeto.

=================

# Trabalhos futuros:

1. Implementar uma gera��o mais din�mica, com o usu�rio informando as posi��es do texto.

2. Implementar upload para tornar o processo din�mico.

3. Implementar login

4. Implementar envio das imagens por e-mail 
