<?php

class cartaogeradoController extends controller{

	public function index(){
		$this->carregarTemplate('cartaogerado',[]);
	}
}