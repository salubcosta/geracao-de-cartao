<?php

class cartaofrenteController extends controller{

	public function index(){
		$this->carregarTemplate('cartaofrente',[]);
	}
}