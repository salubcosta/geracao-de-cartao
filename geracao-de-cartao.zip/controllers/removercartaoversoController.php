<?php

class removercartaoversoController extends controller{

	public function index(){
		$this->carregarTemplate('removercartaoverso', []);
	}
}