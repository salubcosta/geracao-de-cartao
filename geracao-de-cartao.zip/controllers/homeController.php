<?php 

class homeController extends controller{

	public function index(){
		$this->carregarTemplate('home',[]);
	}
}
